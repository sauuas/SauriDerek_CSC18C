/**
 * Derek Sauri
 * sorting linked list
 */
package sortlist;

/**
 *
 * @author derek
 * @param <T>
 */

//got stuck on implementation of comparator

public class SortList<T> {

     public T data;
 public SortList next;
 public SortList back;
    
 public SortList(T data){
        this.data = data;
    }
    
    /**
     * @param args
     */
    public static void main(String[] args) {
        LinkedList theList = new LinkedList();
        
        // push some data
        theList.push('B');
        theList.push(20);
        theList.push(100.25);
        theList.push("cool");
        theList.display();
        //pop first value
        System.out.println("popped off stack: "+theList.pop().data);
        //peek at value
        theList.peek();
        //insert before
        //add to bottom of list
        System.out.println("add to bottom of stack");
        theList.add(21);
        theList.display();
        //"peek" at bottom of stack
        System.out.println("gander at bottom of stack");
        theList.gander();
        //"pop" the bottom of the stack
         System.out.println("clipped off stack: "+theList.clip().data);
        theList.display();
        //remove
        System.out.println("removed "+theList.remove(20).data+" from stack");
        //empty list
        theList.isEmpty();
        theList.clear();
        theList.isEmpty();
    }
    
}
class LinkedList<T>{
    public SortList<stuff> head;
    public SortList<stuff> tail;
    
    LinkedList(){
   head = null;
   tail = null;
    }
    // checks if list is empty
    public void isEmpty(){
        if(head == null){
            System.out.println("the stack is empty now");
        }
        else{
            System.out.println("the stack is not empty");
        }
    }
    //displays whole linked list
    public void display(){
        SortList theLink = head;
        
        System.out.println("display list");
        while(theLink != null){
            System.out.println("link: "+theLink.data);
            theLink = theLink.next;
            System.out.println();
        }
    }
    //pushes new value to top
    public void push(T data){
        SortList<stuff> newLink = new SortList(data);
        System.out.println("push: "+newLink.data);
        if(head != null){
        newLink.next = head;
        head.back = newLink;
        head = newLink;
        }
        else{
            newLink.next = head;
             head = newLink;
              tail = head;
        }
    }
    //adds new value to bottom
    public void add(T data){
        SortList<stuff> newLink = new SortList(data);
        System.out.println("add: "+newLink.data);
        if(tail != null){
            newLink.back = tail;
            tail.next = newLink;
            tail = newLink;
        }
        else{
           newLink.back = tail;
           tail = newLink;
           head = tail;
        }
    }
    //removes top value
    public SortList pop(){
        SortList linkRec = head;
        if(head != null){
            head = head.next;
        }
        else{
            System.out.println("stack is empty");
        }
        return linkRec;
    }
    //removes bottom value
    public SortList clip(){
        SortList linkRec = tail;
        if(tail != null){
            tail = tail.back;
            tail.next = null;
        }
        else{
            System.out.println("stack is empty");
        }
        return linkRec;
    }
    //looks at, but does not remove top data
    public void peek(){
        System.out.println("top of stack "+head.data);
        System.out.println();
    }
    //looks at, but does not remove bottom data
    public void gander(){
         System.out.println("bottom of stack "+tail.data);
        System.out.println();
    }
    // resets list
    public void clear(){
      head = null;
      tail = null;
    }
    //removes specific item from list
    public SortList remove(T data){
       SortList currentLink = head;
       SortList previousLink = head;
       SortList nextLink = head;
       
       //search for data
       while(currentLink.data != data){
           if(currentLink.next == null){
               System.out.println("data not found.");
               return null;
           }
           else{
               previousLink = currentLink;
               currentLink = currentLink.next;
               nextLink = currentLink.next;
           }
       }
       //deal with link that has data
       if(currentLink == head){
           System.out.println("First link: "+currentLink.data);
           head = head.next;
       }
       else{
       System.out.println("current link: "+currentLink.data);
       nextLink.back = currentLink.back;
       previousLink.next = currentLink.next;
       }
       return currentLink;
    }
}