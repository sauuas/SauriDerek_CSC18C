/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sortlist;
/**
 *
 * @author derek
 */
public class stuff {
    public String thing;
    public stuff(String thing){
        super();
        this.thing = thing;
    }

    /**
     *
     * @return
     */
    @Override
    public String toString(){
        return "[thing= " +thing+"]";
    }
}
