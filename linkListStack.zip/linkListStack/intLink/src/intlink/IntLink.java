/*
 * Derek Sauri
 * primitive linked list
 */

package intlink;


public class IntLink {

    public int data;
    public IntLink next;
    
    public IntLink(int data){
        this.data = data;
    }
    public static void main(String[] args) {
        LinkedList theList = new LinkedList();
        
        //check if empty
        theList.isEmpty();
        // push some data
        theList.push(10);
        theList.push(20);
        theList.push(100);
        theList.push(76);
        
        theList.display();
        //pop first value
        System.out.println("popped off stack: "+theList.pop().data);
        //peek at value
        theList.peek();
        //insert before
        System.out.println("show insert before");
        theList.insertBef(25,20);
        theList.display();
        //insert after
        System.out.println("show insert after");
        theList.insertAft(45,20);
        theList.display();
        //remove
        System.out.println("removed "+theList.remove(100).data+" from stack");
        //empty list
        theList.isEmpty();
        theList.clear();
        theList.isEmpty();
        
    }
    
}
class LinkedList{
    public IntLink firstLink;
    
    LinkedList(){
        firstLink = null;
    }
    // checks if list is empty
    public void isEmpty(){
        if(firstLink == null){
            System.out.println("the stack is empty now");
        }
        else{
            System.out.println("the stack is not empty");
        }
    }
    //displays whole linked list
    public void display(){
        IntLink theLink = firstLink;
        
        System.out.println("display list");
        while(theLink != null){
            System.out.println("link: "+theLink.data);
            theLink = theLink.next;
            System.out.println();
        }
    }
    //pushes new value to top
    public void push(int data){
        IntLink newLink = new IntLink(data);
        System.out.println("push: "+newLink.data);
        newLink.next = firstLink;
        firstLink = newLink;
    }
    //removes top value
    public IntLink pop(){
        IntLink linkRec = firstLink;
        if(firstLink != null){
            firstLink = firstLink.next;
        }
        else{
            System.out.println("stack is empty");
        }
        return linkRec;
    }
    //looks at, but does not remove data
    public void peek(){
        System.out.println("top of stack "+firstLink.data);
        System.out.println();
    }
    // resets list
    public void clear(){
        firstLink = null;
    }
    //removes specific item from list
    public IntLink remove(int data){
       IntLink currentLink = firstLink;
       IntLink previousLink = firstLink;
       
       while(currentLink.data != data){
           if(currentLink.next == null){
               return null;
           }
           else{
               previousLink = currentLink;
               currentLink = currentLink.next;
           }
       }
       if(currentLink == firstLink){
           firstLink = firstLink.next;
       }
       else{
       System.out.println("current link: "+currentLink);
       previousLink.next = currentLink.next;
       }
       return currentLink;
    }
    //insert new data before certain value
    public void insertBef(int data, int value){
        IntLink newLink = new IntLink(data);
         IntLink currentLink = firstLink;
       IntLink previousLink = firstLink;
       
        while(currentLink.data != value){
           if(currentLink.next == null){
               return;
           }
           else{
               previousLink = currentLink;
               currentLink = currentLink.next;
           }
       }
        if(currentLink == firstLink){
        newLink.next = firstLink;
        firstLink = newLink;
        }
        else{
            previousLink.next = newLink;
            newLink.next = currentLink;
        }
    }
    //insert new data after certain value
    public void insertAft(int data,int value){
        IntLink newLink = new IntLink(data);
         IntLink currentLink = firstLink;
       
        while(currentLink.data != value){
           if(currentLink.next == null){
               return;
           }
           else{
               currentLink = currentLink.next;
           }
       }
        newLink.next = currentLink.next;
        currentLink.next = newLink;
    }
}