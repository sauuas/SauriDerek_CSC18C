/*
 * Derek Sauri
 * generic linked list
 */

package truelink;

/**
 *
 * @author rcc
 * @param <T>
 */
public class TrueLink<T> {

    public T data;
    public TrueLink next;
    
    public TrueLink(T data){
        this.data = data;
    }
    public static void main(String[] args) {
        LinkedList theList = new LinkedList();
        
        //check if empty
        theList.isEmpty();
        // push some data
        theList.push('B');
        theList.push(20);
        theList.push(100.25);
        theList.push("cool");
        
        theList.display();
        //pop first value
        System.out.println("popped off stack: "+theList.pop().data);
        //peek at value
        theList.peek();
        //insert before
        System.out.println("show insert before");
        theList.insertBef("before",20);
        theList.display();
        //insert after
        System.out.println("show insert after");
        theList.insertAft("after",20);
        theList.display();
        //remove
        System.out.println("removed "+theList.remove(20).data+" from stack");
        //empty list
        theList.isEmpty();
        theList.clear();
        theList.isEmpty();
        
    }
    
}
class LinkedList<T>{
    public TrueLink firstLink;
    
    LinkedList(){
        firstLink = null;
    }
    // checks if list is empty
    public void isEmpty(){
        if(firstLink == null){
            System.out.println("the stack is empty now");
        }
        else{
            System.out.println("the stack is not empty");
        }
    }
    //displays whole linked list
    public void display(){
        TrueLink theLink = firstLink;
        
        System.out.println("display list");
        while(theLink != null){
            System.out.println("link: "+theLink.data);
            theLink = theLink.next;
            System.out.println();
        }
    }
    //pushes new value to top
    public void push(T data){
        TrueLink newLink = new TrueLink(data);
        System.out.println("push: "+newLink.data);
        newLink.next = firstLink;
        firstLink = newLink;
    }
    //removes top value
    public TrueLink pop(){
        TrueLink linkRec = firstLink;
        if(firstLink != null){
            firstLink = firstLink.next;
        }
        else{
            System.out.println("stack is empty");
        }
        return linkRec;
    }
    //looks at, but does not remove data
    public void peek(){
        System.out.println("top of stack "+firstLink.data);
        System.out.println();
    }
    // resets list
    public void clear(){
        firstLink = null;
    }
    //removes specific item from list
    public TrueLink remove(T data){
       TrueLink currentLink = firstLink;
       TrueLink previousLink = firstLink;
       
       while(currentLink.data != data){
           if(currentLink.next == null){
               return null;
           }
           else{
               previousLink = currentLink;
               currentLink = currentLink.next;
           }
       }
       if(currentLink == firstLink){
           firstLink = firstLink.next;
       }
       else{
       System.out.println("current link: "+currentLink.data);
       previousLink.next = currentLink.next;
       }
       return currentLink;
    }
    //insert new data before certain value
    public void insertBef(T data, T value){
        TrueLink newLink = new TrueLink(data);
         TrueLink currentLink = firstLink;
       TrueLink previousLink = firstLink;
       
        while(currentLink.data != value){
           if(currentLink.next == null){
               return;
           }
           else{
               previousLink = currentLink;
               currentLink = currentLink.next;
           }
       }
        if(currentLink == firstLink){
        newLink.next = firstLink;
        firstLink = newLink;
        }
        else{
            previousLink.next = newLink;
            newLink.next = currentLink;
        }
    }
    //insert new data after certain value
    public void insertAft(T data,T value){
        TrueLink newLink = new TrueLink(data);
         TrueLink currentLink = firstLink;
       
        while(currentLink.data != value){
           if(currentLink.next == null){
               return;
           }
           else{
               currentLink = currentLink.next;
           }
       }
        newLink.next = currentLink.next;
        currentLink.next = newLink;
    }
    
}
