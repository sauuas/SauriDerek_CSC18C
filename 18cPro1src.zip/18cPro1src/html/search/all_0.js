var searchData=
[
  ['clear',['clear',['../classpkg18cpro1_1_1_queue.html#a12017eb583aa6822b549a7da073349e7',1,'pkg18cpro1.Queue.clear()'],['../classpkg18cpro1_1_1_stack.html#a96a0531a00d30e7dabf0d1ebd94ed581',1,'pkg18cpro1.Stack.clear()']]]
];
