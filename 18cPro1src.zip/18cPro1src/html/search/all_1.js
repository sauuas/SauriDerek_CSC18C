var searchData=
[
  ['display',['display',['../classpkg18cpro1_1_1_queue.html#a61adfc3f79ec3eb99548d842eeda4535',1,'pkg18cpro1.Queue.display()'],['../classpkg18cpro1_1_1_stack.html#a9f3b685b92366b3e81100aca03d4f747',1,'pkg18cpro1.Stack.display()']]]
];
