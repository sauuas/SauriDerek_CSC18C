/*
 * Derek Sauri
 * AVL tree
 */
package avltree;

/**
 *
 * @author derek
 */
public class AvlTree {
Node root;
    
public AvlTree(){
    this.root = null;
}
//check if tree is empty 
public boolean isEmpty(){
    return root == null;
}
//clear tree
public void clear(){
    root = null;
}
    //preorder print
    public void preorder(){
        preorder(root);
    }
    private void preorder(Node n){
        if(n != null){
            System.out.println(n.data+", ");
            preorder(n.left);
            preorder(n.right);
        }
    }
    //inorder print
    public void inorder(){
        inorder(root);
    }
    private void inorder(Node n){
        if(n != null){
            inorder(n.left);
            System.out.println(n.data+", ");
            inorder(n.right);
        }
    }
    //postorder print
    public void postorder(){
        postorder(root);
    }
    private void postorder(Node n){
        if(n != null){
            postorder(n.left);
            postorder(n.right);
            System.out.println(n.data+", ");
        }
    }
    //get height of node
private int height(Node n){
    return n == null ? -1:n.height;
}
//get higher height value
public int max(int ls, int rs){
    return ls > rs ? ls : rs;
}
//insert into tree
public void insert(int x){
    root = insert(x, root);
}
private Node insert(int x, Node n){

         if (n == null)
             n = new Node(x);
         else if (x < n.data){
             n.left = insert( x, n.left );

             if( height( n.left ) - height( n.right ) == 2 )
                 if( x < n.left.data )
                     n = rotateWithLeftChild( n );
                 else
                     n = doubleWithLeftChild( n);
         }

         else if( x > n.data ){
             n.right = insert( x, n.right );
             if( height( n.right ) - height( n.left ) == 2 )
                 if( x > n.right.data)
                     n = rotateWithRightChild( n );
                 else
                     n = doubleWithRightChild( n );
        }
         else
        n.height = max( height( n.left ), height( n.right ) ) + 1;
         return n;
     }
//remove from tree
//cannot get to function properly
public void remove(int x){
    root = remove(x, root, root);
}
private Node remove(int x, Node n, Node p){
         if (n == null) {
             System.out.println("data not in tree");
         return n;
         }
         else if(x == n.data){
             System.out.println("removed "+x);
             if(p.left == n) p.left = n.left;
             if(p.right == n) p.right = n.right;
                if( height( n.left ) - height( n.right ) == 2 ){
                    if(n.left != null || x < n.left.data )
                        n = rotateWithLeftChild( n );
                    else
                        n = doubleWithLeftChild( n );
                if(n.right != null || x > n.right.data)
                        n = rotateWithRightChild( n );
                    else
                        n = doubleWithRightChild( n );
                }
         }
            else if (x < n.data){
                System.out.println("less than data");
                 p = n;
                n.left = remove( x, n.left,p );
            }
            else if( x > n.data ){
                System.out.println("greater than data");
                 p = n;
                n.right = remove( x, n.right,p );
           }
            else
           n.height = max( height( n.left ), height( n.right ) ) + 1;
         return n;
     }
//rotate with left side
Node rotateWithLeftChild(Node k2){
     Node k1 = k2.left;
         k2.left = k1.right;
         k1.right = k2;
         k2.height = max( height( k2.left ), height( k2.right ) ) + 1;
        k1.height = max( height( k1.left ), k2.height ) + 1;
        return k1;
     }
//rotate with right side
Node rotateWithRightChild(Node k2){
     Node k1 = k2.right;
         k2.right = k1.left;
         k1.left = k2;
         k2.height = max( height( k2.left ), height( k2.right ) ) + 1;
        k1.height = max( height( k1.right ), k2.height ) + 1;
        return k1;
     }
//left right rotation
private Node doubleWithLeftChild(Node n){
    n = rotateWithRightChild(n);
    return rotateWithLeftChild(n);
}
//right left rotation
private Node doubleWithRightChild(Node n){
    n = rotateWithLeftChild(n);
    return rotateWithRightChild(n);
}

    public static void main(String[] args) {
        AvlTree tree = new AvlTree();
       System.out.println("enter 7,8,9,10,11,12,13");
       tree.insert(10);
       tree.insert(9);
       tree.insert(8);
       tree.insert(7);
       tree.insert(11);
       tree.insert(12);
       tree.insert(13);
       System.out.println("preorder");
       tree.preorder();
       System.out.println("inorder");
       tree.inorder();
       System.out.println("postorder");
       tree.postorder();
       System.out.println("removing 13");
       tree.remove(13);
       System.out.println("preorder");
       tree.preorder();
       System.out.println("inorder");
       tree.inorder();
       System.out.println("postorder");
       tree.postorder();
    } 
}
class Node{
    int data;
    int height;
    Node left;
    Node right;
    
    public Node(int n){
    this.data = n;
    this.height = 0;
    this.left = null;
    this.right = null;
}
}
